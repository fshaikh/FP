module.exports = (function () {
   @@CODE
   
    return {
        FP : FP
        };
})();